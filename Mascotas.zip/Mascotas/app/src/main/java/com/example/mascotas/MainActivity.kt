package com.example.mascotas

import android.os.Bundle
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout  // Importación correcta
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout  // Tipo explícito

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Configurar Toolbar
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_menu)

        // Configurar Drawer
        drawerLayout = findViewById(R.id.drawer_layout)
        val navView = findViewById<NavigationView>(R.id.nav_view)

        // Configurar Bottom Navigation
        val bottomNavigation = findViewById<BottomNavigationView>(R.id.bottom_navigation)
        // Inicializar views
        loadFragment(R.layout.mascotashome_layout)

        // Configurar toolbar
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Manejar clics en Bottom Navigation
        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_redsocial -> {
                    // Aquí puedes cambiar el fragmento o mostrar contenido de Productos
                    supportActionBar?.setDisplayHomeAsUpEnabled(true)
                    loadFragment(R.layout.mascotashome_layout)
                    true
                }
                R.id.nav_integrantes -> {
                    // Aquí puedes cambiar el fragmento o mostrar contenido de Servicios
                    supportActionBar?.setDisplayHomeAsUpEnabled(false)
                    loadFragment(R.layout.integrantes_layout)
                    true
                }
                else -> false
            }
        }
        fun loadFragment(fragment: Fragment) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit()
        }

        // Manejar clics en Navigation Drawer
        navView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_students -> {
                    // Acción para Perfil
                    loadFragment(R.layout.perfil_layout)
                    drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED)
                    true
                }
                R.id.nav_teachers -> {
                    // Acción para Fotos
                    loadFragment(R.layout.fotos_layout)
                    drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED)
                    true
                }
                R.id.nav_support -> {
                    // Acción para Soporte
                    loadFragment(R.layout.web_layout)
                    drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED)
                    true
                }
                else -> false
            }
            drawerLayout.closeDrawers()
            true
        }
    }
    //La clase para poder cargar los layouts
    private fun loadFragment(layoutResId: Int) {
        val fragment = DynamicFragment.newInstance(layoutResId)
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    // Para el toogle
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                drawerLayout.openDrawer(GravityCompat.START)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    // Cierro el drawer con botón atrás
    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }

    //Utilizo esta clase para poder cargar los layaouts de forma directa
    class DynamicFragment : Fragment() {

        private var layoutResId: Int = 0

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            arguments?.let {
                layoutResId = it.getInt(ARG_LAYOUT_ID)
            }
        }

        override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
        ): View? {
            return inflater.inflate(layoutResId, container, false)
        }

        companion object {
            private const val ARG_LAYOUT_ID = "layout_id"

            fun newInstance(layoutResId: Int): DynamicFragment {
                val fragment = DynamicFragment()
                val args = Bundle()
                args.putInt(ARG_LAYOUT_ID, layoutResId)
                fragment.arguments = args
                return fragment
            }
        }
    }
}